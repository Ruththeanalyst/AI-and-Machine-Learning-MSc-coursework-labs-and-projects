from flask import Flask, jsonify, request
from flask_cors import CORS
from pydantic import ValidationError
from typing import List

from maze_data import MAZE, bfs, dfs
from models import SolveRequest, MazeResponse, SolveResponse

app = Flask(__name__)
CORS(app)

def _in_bounds(maze: List[List[str]], row: int, col: int) -> bool:
    return 0 <= row < len(maze) and 0 <= col < len(maze[0])

def _passable(maze: List[List[str]], row: int, col: int) -> bool:
    return maze[row][col] != "#"

@app.get("/maze")
def get_maze():
    rows, cols=len(MAZE), len(MAZE[0])
    resp= MazeResponse(maze=MAZE, rows=rows, cols=cols)
    return jsonify(resp.model_dump()), 200

@app.post("/solve")
def post_solve():
    return jsonify({"message": "This message should be a solved path for a maze!"}), 200

if __name__ == "__main__":
    app.run(port=5000)