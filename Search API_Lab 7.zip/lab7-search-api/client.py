import requests, json
BASE = "http://127.0.0.1:5000"

def pretty_print(x): 
    return json.dumps(x, indent=2)

print("GET /maze")
resp = requests.get(f"{BASE}/maze")
print(resp.status_code, pretty_print(resp.json()))

for algo in ("bfs","dfs"):
    print(f"\nPOST /solve (algo={algo})")
    resp = requests.post(f"{BASE}/solve", json={"start": [-1,-1], "end": [5,5], "algorithm": algo})
    print(resp.status_code, pretty_print(resp.json()))