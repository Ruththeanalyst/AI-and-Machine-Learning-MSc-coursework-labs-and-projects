from collections import deque

MAZE = [
    ['#', '#', '#', '#', '#', '#', '#'],
    ['#', 'S', ' ', ' ', '#', ' ', '#'],
    ['#', '#', '#', ' ', '#', ' ', '#'],
    ['#', ' ', ' ', ' ', ' ', ' ', '#'],
    ['#', ' ', '#', '#', '#', ' ', '#'],
    ['#', ' ', ' ', ' ', ' ', 'E', '#'],
    ['#', '#', '#', '#', '#', '#', '#']
]

def bfs(maze, start, end):
    queue = deque([[start]])
    visited = {start}
    rows, cols = len(maze), len(maze[0])

    while queue:
        path = queue.popleft()
        y, x = path[-1]

        if (y, x) == end:
            return path
        
        for dy, dx in [(0,1), (0,-1), (1,0), (-1,0)]:
            next_x, next_y = x + dx, y + dy
            neighbor = (next_y, next_x)
            if (0 <= next_y < rows and 0 <= next_x < cols and maze[next_y][next_x] != '#' and neighbor not in visited):
                visited.add((next_y, next_x))
                queue.append(path + [(next_y, next_x)])

    return None

def dfs(maze, start, end):
    stack = [[start]]
    visited = {start}
    rows, cols = len(maze), len(maze[0])

    while stack:
        path = stack.pop()
        y, x = path[-1]

        if (y, x) == end:
            return path
        
        for dy, dx in [(0,1),(0,-1),(1,0),(-1,0)]:
            next_x, next_y = x + dx, y + dy
            neighbor = (next_y, next_x)

            if (0 <= next_y < rows and 0 <= next_x < cols and maze[next_y][next_x] != '#' and neighbor not in visited):
                visited.add((next_y, next_x))
                stack.append(path + [(next_y, next_x)])

    return None