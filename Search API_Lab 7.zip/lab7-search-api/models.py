from pydantic import BaseModel, Field, model_validator
from typing import Tuple, List, Optional, Literal

Coord = Tuple[int, int]

class SolveRequest(BaseModel):
    start: Coord = Field(..., description="(row, col)")
    end: Coord = Field(..., description="(row, col)")
    algorithm: Literal["bfs", "dfs"] = "bfs"

    @model_validator(mode="after")
    def validate_coords(self):
        for coordinate in (*self.start, *self.end):
            if not isinstance(coordinate, int):
                raise ValueError("Coordinates must be integers")
        return self

class MazeResponse(BaseModel):
    maze: List[List[str]]
    rows: int
    cols: int

class SolveResponse(BaseModel):
    path: List[Coord]
    length: int
    algorithm: Literal["bfs", "dfs"]